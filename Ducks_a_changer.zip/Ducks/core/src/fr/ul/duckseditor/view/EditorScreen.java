package fr.ul.duckseditor.view;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.sun.prism.image.ViewPort;
import fr.ul.duckseditor.dataFactory.TextureFactory;
import fr.ul.duckseditor.model.Listener;
import fr.ul.duckseditor.model.Monde;
import javafx.scene.shape.Circle;

public class EditorScreen extends ScreenAdapter {
    private int worldHeight;
    private int worldWidth;
    private SpriteBatch sb;
    private OrthographicCamera camera;
    private Box2DDebugRenderer debug;
    private Monde mde;
    private Texture backg;

    public EditorScreen () {
        sb=new SpriteBatch();
        mde = new Monde();
        camera = new OrthographicCamera(64,36);
        camera.position.set(camera.viewportWidth/2f,camera.viewportHeight/2f,0);
        camera.update();
        sb.setProjectionMatrix(camera.combined);
        debug= new Box2DDebugRenderer();
        Listener l = new Listener(camera,mde);
        Gdx.input.setInputProcessor(l);

    }

    @Override
    public void render (float delta) {
        Gdx.gl.glClearColor(0,1,0,1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        mde.update(delta);
        sb.begin();
        backg = TextureFactory.getBackground();
        sb.draw(backg, 0, 0,64 ,36);
        mde.draw(sb);
        sb.end();

        sb.begin();
        debug.render(mde.getWorld(),camera.combined);
        sb.end();
    }

    @Override
    public void dispose () {
        sb.dispose();
    }

    private Vector3 inversion(Vector3 v){
        return camera.unproject(v);
    }
}
