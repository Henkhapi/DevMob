package fr.ul.duckseditor.boutons.editeur;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import fr.ul.duckseditor.boutons.bloc.CarreBouton;
import fr.ul.duckseditor.boutons.cible.BanditBouton;
import fr.ul.duckseditor.boutons.cible.PrisonnierBouton;
import fr.ul.duckseditor.dataFactory.TextureFactory;
import fr.ul.duckseditor.model.Monde;
import fr.ul.duckseditor.objets.Objet;
import fr.ul.duckseditor.boutons.bloc.RectangleBouton;

import java.util.ArrayList;

public class Editeur extends Objet {
    private Monde monde;
    private Texture editeur;
    private int posx;
    private int posy;
    private ArrayList<Bouton> boutons;
    public PlayStop ps;

    public Editeur(Monde m, int posx, int posy){
        super(m,posx,posy,0);

        this.monde = m;
        this.posx = posx;
        this.posy = posy;
        boutons = new ArrayList<Bouton>();
        ps = new PlayStop(monde,5,32);
        boutons.add(ps);
        boutons.add(new Load(monde, 5,28));
        boutons.add(new Save(monde,2,22));
        boutons.add(new Rewrite(monde,8,22));
        boutons.add(new RectangleBouton(monde,5,16));
        boutons.add(new CarreBouton(monde,5,12));
        boutons.add(new PrisonnierBouton(monde,5,9.5f));
        boutons.add(new BanditBouton(monde,5,7));
        boutons.add(new Close(monde,5,2));

    }

    public void draw(SpriteBatch sb) {
        editeur = TextureFactory.getEditPanel();
        sb.draw(editeur,posx,posy,12,36);
        for(Objet o : boutons){
            o.draw(sb);
        }

    }


    public ArrayList<Bouton> getBoutons() {
        return boutons;
    }

    public PlayStop getPlayStop() {
        return ps;
    }
}