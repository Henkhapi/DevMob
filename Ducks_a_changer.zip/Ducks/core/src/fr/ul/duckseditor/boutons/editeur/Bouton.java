package fr.ul.duckseditor.boutons.editeur;

import com.badlogic.gdx.physics.box2d.Body;
import fr.ul.duckseditor.model.Monde;
import fr.ul.duckseditor.objets.Objet;

public abstract class Bouton extends Objet {

    public Bouton(Monde m, float posx, float posy, int id) {
        super(m, posx, posy,id);
    }

}
