package fr.ul.duckseditor.boutons.cible;

import com.badlogic.gdx.physics.box2d.Body;
import fr.ul.duckseditor.boutons.editeur.Bouton;
import fr.ul.duckseditor.model.Monde;
import fr.ul.duckseditor.objets.Objet;

public abstract class CibleBouton extends Bouton {

    public CibleBouton(Monde m, float posx, float posy,int id) {
        super(m, posx, posy,id);
    }
}
