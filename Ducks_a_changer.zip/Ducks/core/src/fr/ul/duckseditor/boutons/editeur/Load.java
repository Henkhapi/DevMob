package fr.ul.duckseditor.boutons.editeur;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import fr.ul.duckseditor.dataFactory.TextureFactory;
import fr.ul.duckseditor.model.Monde;
import fr.ul.duckseditor.objets.Objet;

public class Load extends Bouton {
    private Monde monde;
    private BodyDef bd;
    private Texture load;
    private int posx;
    private int posy;
    private Body body;

    public Load(Monde m, int posx, int posy){
        super(m,posx,posy,2);
        this.monde = m;
        this.posx = posx;
        this.posy = posy;
        this.bd = new BodyDef();
        bd.type = BodyDef.BodyType.StaticBody;
        bd.position.set(posx,posy);
        body = monde.getWorld().createBody(bd);
        FixtureDef fixtureDef = new FixtureDef();
        Vector2[] pts = {new Vector2(0f,0f),new Vector2(0f,3f),new Vector2(3f,3f),new Vector2(3f,0f)};
        PolygonShape c = new PolygonShape();
        c.set(pts);
        fixtureDef.shape = c;
        body.createFixture(fixtureDef);
        load = TextureFactory.getLoad();
        c.dispose();
    }

    public void draw(SpriteBatch sb) {
        sb.draw(load,body.getPosition().x,body.getPosition().y,0,0,3,3,1,1,
                (float) Math.toDegrees((double) body.getAngle()),0,0,
                load.getWidth(),load.getHeight(),false,false);
    }


}
