package fr.ul.duckseditor.boutons.bloc;

import fr.ul.duckseditor.boutons.editeur.Bouton;
import fr.ul.duckseditor.model.Monde;
import fr.ul.duckseditor.objets.Objet;

public abstract class BlocBouton extends Bouton {
    public BlocBouton(Monde m, float posx, float posy,int id) {
        super(m, posx, posy,id);
    }
}
