package fr.ul.duckseditor.model;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.World;
import fr.ul.duckseditor.boutons.editeur.Bouton;
import fr.ul.duckseditor.boutons.editeur.Editeur;
import fr.ul.duckseditor.boutons.editeur.PlayStop;
import fr.ul.duckseditor.objets.*;
import fr.ul.duckseditor.objets.bloc.Carre;
import fr.ul.duckseditor.objets.bloc.Rectangle;
import fr.ul.duckseditor.objets.cible.Bandit;
import fr.ul.duckseditor.objets.cible.Prisonnier;

import java.util.ArrayList;

public class Monde {
    private Bord bord;
    private World world;
    private Vector2 v;
    private ArrayList<Objet> objets;
    private Editeur editeur;
    private int compteur;
    private boolean playingMonde;

    public Monde(){
        v= new Vector2(0,-15);
        this.world = new World(v,true);
        this.editeur = new Editeur(this,0,0);
        this.bord = new Bord(this,0,0);
        objets = new ArrayList<Objet>();
        this.compteur = 0;
        playingMonde = false;

    }

    public World getWorld(){return world;}

    public void draw (SpriteBatch sb){
        editeur.draw(sb);
        for(Objet o : objets){
            o.draw(sb);
        }
        bord.draw(sb);

    }

    public void update(float delta) {
        if(playingMonde){this.getWorld().step(delta,6,2);}
    }

    public void addObjet(Objet o){
        compteur++;
        System.out.println("Il y a "+compteur+" objets");
        objets.add(o);

    }

    public ArrayList<Objet> getObjets() {
        return objets;
    }

    public ArrayList<Bouton> getBoutons(){ return this.editeur.getBoutons(); }

    public Editeur getEditeur(){return this.editeur;}

    public Bord getBord(){
        return this.bord;
    }

    public void setPlayingMonde(){
        if(playingMonde==true){
            playingMonde=false;
            this.getEditeur().getPlayStop().setTexture(1);
        }
        else{
            playingMonde = true;
            this.getEditeur().getPlayStop().setTexture(0);
        }
    }
}
