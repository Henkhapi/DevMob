package fr.ul.duckseditor.model;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.QueryCallback;
import com.badlogic.gdx.physics.box2d.World;
import fr.ul.duckseditor.boutons.cible.PrisonnierBouton;
import fr.ul.duckseditor.boutons.editeur.Bouton;
import fr.ul.duckseditor.boutons.editeur.Editeur;
import fr.ul.duckseditor.boutons.editeur.PlayStop;
import fr.ul.duckseditor.objets.Objet;
import fr.ul.duckseditor.objets.bloc.Carre;
import fr.ul.duckseditor.objets.bloc.Rectangle;
import fr.ul.duckseditor.objets.cible.Bandit;
import fr.ul.duckseditor.objets.cible.Prisonnier;

import java.util.ArrayList;

import static java.lang.Math.atan;
import static java.lang.Math.atan2;


public class Listener implements InputProcessor{
    private ArrayList<Body> bodys;
    private ArrayList<Integer> codes;
    private ArrayList<Bouton> boutons;
    private ArrayList<Objet> objets;
    private Camera camera;
    private Monde monde;
    private World world;
    private Vector3 v3;

    public Listener (Camera c, Monde mde){
        bodys = new ArrayList<Body>();
        codes = new ArrayList<Integer>();
        this.camera=c;
        this.monde = mde;

    }
    @Override
    public boolean keyDown(int keycode) {
        codes.add(Integer.valueOf(keycode));
        if(keycode==131){
            Gdx.app.exit();
        }
        return true;
    }


    @Override
    public boolean keyUp(int keycode) {
        return true;
    }

    @Override
    public boolean keyTyped(char character) {
        return true;
    }

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        world = monde.getWorld();
        boutons = monde.getBoutons();
        objets  = monde.getObjets();
        v3 = new Vector3(screenX,screenY,0);
        camera.unproject(v3);
        QueryCallback qcb = new QueryCallback(){
            @Override
            public boolean reportFixture(Fixture fixture) {
                if(fixture.getBody().getUserData() != monde.getBord())
                bodys.add(fixture.getBody());
                return true;
            }
        };
        monde.getWorld().QueryAABB(qcb,v3.x-0.1f,v3.y-0.1f,v3.x+0.1f,v3.y+0.1f );
        for(Body bod : bodys){
            for(Objet b : boutons) {
                if (bod.equals(b.getBody())) {
                    switch (b.getId()) {
                        case 2:
                            this.load();
                            break;
                        case 3:
                            this.playstop();
                            break;
                        case 4:
                            this.rewrite();
                            break;
                        case 5:
                            this.save();
                            break;
                        case 7:
                            new Carre(this.monde, v3.x, v3.y);
                            break;
                        case 8:
                            new Rectangle (this.monde, v3.x, v3.y);
                            break;
                        case 9:
                            new Bandit(this.monde, v3.x, v3.y);
                            break;
                        case 10:
                            new Prisonnier(this.monde, v3.x, v3.y);
                            break;
                        default:
                            break;
                    }
                }
            }
        }
        bodys.clear();
        return true;
    }

    private void load() {
    }

    private void playstop() {
        this.monde.setPlayingMonde();
    }

    private void rewrite() {
    }

    private void save() {
    }


    @Override
    public boolean touchUp(int screenX, int screenY, int pointer, int button) {

        //this.objets.clear();

        return true;
    }

    @Override
    public boolean touchDragged(int screenX, int screenY, int pointer) {
        world = monde.getWorld();
        boutons = monde.getBoutons();
        objets  = monde.getObjets();
        Vector3 v3b = new Vector3(screenX,screenY,0);
        camera.unproject(v3b);
        Vector2 v2 = new Vector2(this.v3.x,this.v3.y);
        Vector2 v2b = new Vector2(v3b.x,v3b.y);
       /* QueryCallback qcb = new QueryCallback(){
            @Override
            public boolean reportFixture(Fixture fixture) {
                if(fixture.getBody().getUserData() != monde.getBord())
                    bodys.add(fixture.getBody());
                return true;
            }
        };
        monde.getWorld().QueryAABB(qcb,v3b.x-0.1f,v3b.y-0.1f,v3b.x+0.1f,v3b.y+0.1f );*/
        for(Body bod : bodys) {
            for (Objet b : objets) {
                if (bod.equals(b.getBody())) {
                    switch (b.getId()) {
                        case -1:
                            break;
                        default:
                            b.getBody().setActive(false);
                            if(Gdx.input.isButtonPressed(Input.Buttons.LEFT) || Gdx.input.isTouched(0)) {
                                b.getBody().setTransform();
                            }
                            else{
                                if(Gdx.input.isButtonPressed(Input.Buttons.RIGHT)|| Gdx.input.isTouched(1)){

                                    b.getBody().setTransform(bod.getPosition().x,bod.getPosition().y,bod.getAngle() +v2.angleRad(v2b) );
                                }
                                //Math.toRadians()
                            }
                            break;

                    }
                }
            }
        }

        return true;
    }

    @Override
    public boolean mouseMoved(int screenX, int screenY) {
        return true;
    }

    @Override
    public boolean scrolled(int amount) {
        return true;
    }


}
