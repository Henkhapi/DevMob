package fr.ul.duckseditor;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import fr.ul.duckseditor.dataFactory.TextureFactory;
import fr.ul.duckseditor.model.Listener;
import fr.ul.duckseditor.view.EditorScreen;

public class DucksEditor extends Game {
	EditorScreen es;

	@Override
	public void create () {
		es= new EditorScreen();
		this.setScreen(es);
	}

	@Override
	public void dispose() {
		super.dispose();
	}
}
