package fr.ul.duckseditor.dataFactory;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class TextureFactory {
    private static Texture background = new Texture("images/background.png");
    private static Texture beam = new Texture ("images/beam.png");
    private static Texture block= new Texture ("images/block.png");
    private static Texture cancel= new Texture ("images/cancel.png");
    private static Texture duck= new Texture ("images/duck.png");
    private static Texture editPanel= new Texture ("images/editPanel.png");
    private static Texture leftarrow= new Texture ("images/leftarrow.png");
    private static Texture load= new Texture ("images/Load.png");
    private static Texture play= new Texture ("images/Play.png");
    private static Texture rewrite= new Texture ("images/Rewrite.png");
    private static Texture rightarrow= new Texture ("images/rightarrow.png");
    private static Texture save= new Texture ("images/Save.png");
    private static Texture stop= new Texture ("images/Stop.png");
    private static Texture targetbeige= new Texture ("images/targetbeige.png");
    private static Texture targetblue= new Texture ("images/targetblue.png");
    private static Texture trash= new Texture ("images/Trash.png");

    public static Texture getBackground(){
        return background;
    }

    public static Texture getBeam() {
        return beam;
    }

    public static Texture getBlock() {
        return block;
    }

    public static Texture getCancel() {
        return cancel;
    }

    public static Texture getDuck() {
        return duck;
    }

    public static Texture getEditPanel() {
        return editPanel;
    }

    public static Texture getLeftarrow() {
        return leftarrow;
    }

    public static Texture getLoad() {
        return load;
    }

    public static Texture getPlay() {
        return play;
    }

    public static Texture getRewrite() {
        return rewrite;
    }

    public static Texture getRightarrow() {
        return rightarrow;
    }

    public static Texture getSave() {
        return save;
    }

    public static Texture getStop() {
        return stop;
    }

    public static Texture getTargetbeige() {
        return targetbeige;
    }

    public static Texture getTargetblue() {
        return targetblue;
    }

    public static Texture getTrash() {
        return trash;
    }
}


