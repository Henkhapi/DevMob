package fr.ul.duckseditor.objets;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import fr.ul.duckseditor.model.Monde;

public abstract class Objet {
    protected Body body;
    protected Monde monde;
    protected int id;

    public Objet(Monde m, float posx, float posy, int id){
        BodyDef bd = new BodyDef();
        bd.position.set(posx,posy);
        this.monde = m;
        this.id = id;
    }

    public abstract void draw(SpriteBatch sb);

    public Body getBody(){return body;}

    public int getId(){return id;}
}
