package fr.ul.duckseditor.objets.cible;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import fr.ul.duckseditor.dataFactory.TextureFactory;
import fr.ul.duckseditor.model.Monde;

public class Prisonnier extends Cible{
    private float posx;
    private float posy;
    private Monde monde;
    private BodyDef bd;
    private Texture prisonnier;
    private int id;

    public Prisonnier(Monde m, float posx, float posy){
        super(m,posx,posy,0);
        this.monde = m;
        this.posx = posx;
        this.posy = posy;
        this.id = 0;
        this.bd = new BodyDef();
        bd.type = BodyDef.BodyType.DynamicBody;
        bd.position.set(posx,posy);
        body = monde.getWorld().createBody(bd);
        FixtureDef fixtureDef = new FixtureDef();
        CircleShape cs = new CircleShape();
        cs.setRadius(2/2);
        fixtureDef.shape = cs;
        fixtureDef.density = 0.5f;
        fixtureDef.restitution = 0.5f;
        body.setUserData(this);
        body.createFixture(fixtureDef);
        prisonnier = TextureFactory.getTargetbeige();
        cs.dispose();
        monde.addObjet(this);
    }

    public void draw(SpriteBatch sb) {
        sb.draw(prisonnier,body.getPosition().x-(2/2f),body.getPosition().y-(2/2f),1,1,2,2,1,1,
                (float)(body.getAngle()*180/Math.PI),0,0,
                prisonnier.getWidth(),prisonnier.getHeight(),false,false);
    }
}