package fr.ul.duckseditor.objets;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.physics.box2d.*;
import fr.ul.duckseditor.model.Monde;

public class Bord extends Objet{
    private Monde monde;
    private BodyDef bd;
    private int id;

    public Bord(Monde m, int posx, int posy){
        super(m,posx,posy,-1);
        this.monde = m;
        this.bd = new BodyDef();
        this.id = -1;
        bd.type = BodyDef.BodyType.StaticBody;
        bd.position.set(posx,posy);
        Body body1 = monde.getWorld().createBody(bd);
        FixtureDef fixtureDef = new FixtureDef();
        float[] pts = {12f,6f,
                12f,36f,
                64f,36f,
                64f,6f,
                12f,6f};
        ChainShape cs = new ChainShape();
        cs.createChain(pts);
        fixtureDef.shape = cs;
        body1.createFixture(fixtureDef);
        cs.dispose();
    }

    @Override
    public void draw(SpriteBatch sb) {
    }

    public int getId(){return this.id;}
}
