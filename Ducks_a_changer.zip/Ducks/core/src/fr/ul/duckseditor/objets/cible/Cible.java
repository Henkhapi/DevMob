package fr.ul.duckseditor.objets.cible;

import fr.ul.duckseditor.model.Monde;
import fr.ul.duckseditor.objets.Objet;

public abstract class Cible extends Objet {

    public Cible(Monde m, float posx, float posy, int id) {
        super(m, posx, posy,id);
    }
}
