package fr.ul.duckseditor.objets.cible;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import fr.ul.duckseditor.dataFactory.TextureFactory;
import fr.ul.duckseditor.model.Monde;
import fr.ul.duckseditor.objets.Objet;

public class Heros extends Objet {
    private float posx;
    private float posy;
    private Monde monde;
    private BodyDef bd;
    private Texture heros;
    private int id;

    public Heros(Monde m, float posx, float posy){
        super(m,posx,posy,0);
        this.monde = m;
        this.posx = posx;
        this.posy = posy;
        this.bd = new BodyDef();
        bd.type = BodyDef.BodyType.DynamicBody;
        bd.position.set(posx,posy);
        body = monde.getWorld().createBody(bd);
        FixtureDef fixtureDef = new FixtureDef();
        CircleShape cs = new CircleShape();
        fixtureDef.shape = cs;
        fixtureDef.density = 0.5f;
        fixtureDef.restitution = 0.5f;
        body.createFixture(fixtureDef);
        body.setUserData(this);
        Vector2 v2 = new Vector2(body.getPosition());
        heros = TextureFactory.getTargetblue();
        cs.dispose();
    }

    public void draw(SpriteBatch sb) {
        sb.draw(heros,body.getPosition().x-4/2f,body.getPosition().y-4/2f,4/2f,4/2f,2,2,1,1,
                (float) Math.toDegrees((double) body.getAngle()),0,0,
                heros.getWidth(),heros.getHeight(),false,false);
    }
}