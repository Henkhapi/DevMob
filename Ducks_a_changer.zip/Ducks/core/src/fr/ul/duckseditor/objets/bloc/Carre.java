package fr.ul.duckseditor.objets.bloc;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import fr.ul.duckseditor.dataFactory.TextureFactory;
import fr.ul.duckseditor.model.Monde;

public class Carre extends Bloc {
    private Monde monde;
    private BodyDef bd;
    private Texture carre;
    private float posx;
    private float posy;
    private int id;

    public Carre(Monde m, float posx, float posy){
        super(m,posx,posy,0);
        this.monde = m;
        this.posx = posx;
        this.posy = posy;
        this.id = 0;
        this.bd = new BodyDef();
        bd.type = BodyDef.BodyType.DynamicBody;
        bd.position.set(posx,posy);
        body = monde.getWorld().createBody(bd);
        FixtureDef fixtureDef = new FixtureDef();
        Vector2[] pts = {new Vector2(0f,0f),new Vector2(0f,2f),new Vector2(2f,2f),new Vector2(2f,0f)};
        PolygonShape c = new PolygonShape();
        c.set(pts);
        fixtureDef.density = 1f;
        fixtureDef.restitution = 0.5f;
        fixtureDef.shape = c;
        body.setUserData(this);
        body.createFixture(fixtureDef);
        carre = TextureFactory.getBlock();
        c.dispose();
        monde.addObjet(this);
    }

    public void draw(SpriteBatch sb) {
        sb.draw(carre,body.getPosition().x,body.getPosition().y,0,0,2,2,1,1,
                (float) Math.toDegrees((double) body.getAngle()),0,0,
                carre.getWidth(),carre.getHeight(),false,false);
    }

    public int getId(){return this.id;}
}
