package fr.ul.duckseditor.objets.bloc;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import fr.ul.duckseditor.dataFactory.TextureFactory;
import fr.ul.duckseditor.model.Monde;

public class Rectangle extends Bloc {
    private Monde monde;
    private BodyDef bd;
    private Texture rectangle;
    private float posx;
    private float posy;
    private int id;

    public Rectangle(Monde m, float posx, float posy){
        super(m,posx,posy,0);
        this.monde = m;
        this.posx = posx;
        this.posy = posy;
        this.id = 0;
        this.bd = new BodyDef();
        bd.type = BodyDef.BodyType.DynamicBody;
        bd.position.set(posx,posy);
        body = monde.getWorld().createBody(bd);
        FixtureDef fixtureDef = new FixtureDef();
        Vector2[] pts = {new Vector2(0f,0f),
                new Vector2(0f,4f),
                new Vector2(1f,4f),
                new Vector2(1f,0f)};
        PolygonShape c = new PolygonShape();
        c.set(pts);
        fixtureDef.shape = c;
        fixtureDef.density = 0.5f;
        fixtureDef.restitution = 0.5f;
        body.createFixture(fixtureDef);
        body.setUserData(this);
        rectangle = TextureFactory.getBlock();
        c.dispose();
        monde.addObjet(this);
    }

    public void draw(SpriteBatch sb) {
        sb.draw(rectangle,body.getPosition().x,body.getPosition().y,0,0,1,4,1,1,
                (float) Math.toDegrees((double) body.getAngle()),0,0,
                rectangle.getWidth(),rectangle.getHeight(),false,false);
    }
}